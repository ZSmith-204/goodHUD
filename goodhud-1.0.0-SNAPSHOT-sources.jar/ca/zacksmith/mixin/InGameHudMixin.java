package ca.zacksmith.mixin;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.class_1657;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_4587;
import net.minecraft.class_9779;

@Mixin(class_329.class)
public class InGameHudMixin {

    // 1. Completely hide the Armor Bar (Fixed: removed 'static')
    @Inject(method = "renderArmor", at = @At("HEAD"), cancellable = true)
    private void hideArmorBar(class_332 context, class_1657 player, int i, int j, int k, int l, CallbackInfo ci) {
        ci.cancel();
    }

    // 2. Scale down, reposition, and set 50% opacity for the Hotbar
    @Inject(method = "renderHotbar", at = @At("HEAD"))
    private void scaleHotbarStart(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        class_4587 matrices = context.method_51448();
        matrices.method_22903();

        class_310 client = class_310.method_1551();
        float scale = 0.75f;
        float screenWidth = client.method_22683().method_4486();
        float screenHeight = client.method_22683().method_4502();

        // Move to center, scale, then shift back by half the hotbar width (91) and down below crosshair (+15)
        matrices.method_46416(screenWidth / 2.0f, screenHeight / 2.0f + 15.0f, 0);
        matrices.method_22905(scale, scale, 1.0f);
        matrices.method_46416(-91.0f, 0, 0);

        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 0.5F);
    }

    @Inject(method = "renderHotbar", at = @At("TAIL"))
    private void scaleHotbarEnd(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        context.method_51448().method_22909();
    }

    // 3. Scale down, reposition, and set 50% opacity for Status Bars (Health and Hunger)
    @Inject(method = "renderStatusBars", at = @At("HEAD"))
    private void scaleStatusBarsStart(class_332 context, CallbackInfo ci) {
        class_4587 matrices = context.method_51448();
        matrices.method_22903();

        class_310 client = class_310.method_1551();
        float scale = 0.75f;
        float screenWidth = client.method_22683().method_4486();
        float screenHeight = client.method_22683().method_4502();

        // Move to center, scale, then shift back by half width (-91) and slightly above hotbar (-5)
        matrices.method_46416(screenWidth / 2.0f, screenHeight / 2.0f - 5.0f, 0);
        matrices.method_22905(scale, scale, 1.0f);
        matrices.method_46416(-91.0f, 0, 0);

        RenderSystem.enableBlend();
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 0.5F);
    }

    @Inject(method = "renderStatusBars", at = @At("TAIL"))
    private void scaleStatusBarsEnd(class_332 context, class_9779 tickCounter, CallbackInfo ci) {
        RenderSystem.setShaderColor(1.0F, 1.0F, 1.0F, 1.0F);
        context.method_51448().method_22909();
    }
}