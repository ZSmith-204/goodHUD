package ca.zacksmith; // Make sure this matches your folder package structure

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.fabricmc.api.ClientModInitializer;

public class goodHUD implements ClientModInitializer {
    // It's good practice to set up a logger for debugging messages
    public static final String MOD_ID = "goodhud";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LOGGER.info( "Initializing GoodHUD client-side modifications.");
        
        // Since your UI shifts and scaling are handled via Mixins, 
        // you typically don't need to register event handlers here unless 
        // you want to add a configuration screen or keybinds later.
    }
}